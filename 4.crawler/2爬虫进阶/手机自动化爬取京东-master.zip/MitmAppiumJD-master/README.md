# MitmAppiumJD
MitmProxy and Appium to Crawl Comments in JD APP
